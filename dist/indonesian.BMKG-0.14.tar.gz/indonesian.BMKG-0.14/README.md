# Indonesian Earthquake Update
this is an package of latest indonesian earthquake

## HOW IT WORK?
This package uses beautifulsoup4 and request, the result of this package is the latest earthquake update information in the Indonesian region

## AUTHOR
Muhammad Afrizal